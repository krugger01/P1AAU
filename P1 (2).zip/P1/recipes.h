struct Opskrift
{
    int food_preference;
    int points;
    char index;
    char ingredients[10][30];
};

/*printf("       Meat       |      Vegetables    |     Other  \n");  
    printf("1: Salmon         | 6:  Carrot         | 11: Egg    \n"); 
    printf("2: Ground beef    | 7:  Potato         | 12: Tofu   \n"); 
    printf("3: Chicken        | 8:  Tomato         | 13: Rice   \n"); 
    printf("4: Bacon          | 9:  Mushrooms      | 14: Pasta  \n"); 
    printf("5: Ground pork    | 10: Onions         | 15: Beans  \n"); */

struct Opskrift recipes[54];

////-----Vegan-----////
//Nr 1
recipes[0].index = 1;
recipes[0].food_preference = 1;
strcpy(recipes[0].ingredients[0], "12");
strcpy(recipes[0].ingredients[1], "10");
strcpy(recipes[0].ingredients[2], "9");
//Nr 2
recipes[1].index = 2;
recipes[1].food_preference = 1;
strcpy(recipes[1].ingredients[0], "13");
strcpy(recipes[1].ingredients[1], "9");
strcpy(recipes[1].ingredients[2], "15");
//Nr 3
recipes[2].index = 3;
recipes[2].food_preference = 1;
strcpy(recipes[2].ingredients[0], "10");
strcpy(recipes[2].ingredients[1], "7");
//Nr 4
recipes[3].index = 4;
recipes[3].food_preference = 1;
strcpy(recipes[3].ingredients[0], "6");
strcpy(recipes[3].ingredients[1], "7");
strcpy(recipes[3].ingredients[2], "14");
//Nr 5
recipes[4].index = 5;
recipes[4].food_preference = 1;
strcpy(recipes[4].ingredients[0], "6");
strcpy(recipes[4].ingredients[1], "10");
strcpy(recipes[4].ingredients[2], "8");
//Nr 6
recipes[5].index = 6;
recipes[5].food_preference = 1;
strcpy(recipes[5].ingredients[0], "8");
strcpy(recipes[5].ingredients[1], "10");
strcpy(recipes[5].ingredients[2], "15");
//Nr 7
recipes[6].index = 7;
recipes[6].food_preference = 1;
strcpy(recipes[6].ingredients[0], "7");
strcpy(recipes[6].ingredients[1], "12");
//Nr 8
recipes[7].index = 8;
recipes[7].food_preference = 1;
strcpy(recipes[7].ingredients[0], "8");
strcpy(recipes[7].ingredients[1], "10");
strcpy(recipes[7].ingredients[2], "14");
//Nr 9
recipes[8].index = 9;
recipes[8].food_preference = 1;
strcpy(recipes[8].ingredients[0], "10");
//Nr 10
recipes[9].index = 10;
recipes[9].food_preference = 1;
strcpy(recipes[9].ingredients[0], "12");
strcpy(recipes[9].ingredients[1], "9");
strcpy(recipes[9].ingredients[2], "3");
//Nr 11
recipes[10].index = 11;
recipes[10].food_preference = 1;
strcpy(recipes[10].ingredients[0], "8");
strcpy(recipes[10].ingredients[1], "14");
//Nr 12
recipes[11].index = 12;
recipes[11].food_preference = 1;
strcpy(recipes[11].ingredients[0], "12");
strcpy(recipes[11].ingredients[1], "7");
//Nr 13
recipes[12].index = 13;
recipes[12].food_preference = 1;
strcpy(recipes[12].ingredients[0], "10");
strcpy(recipes[12].ingredients[1], "9");
//Nr 14
recipes[13].index = 14;
recipes[13].food_preference = 1;
strcpy(recipes[13].ingredients[0], "12");
strcpy(recipes[13].ingredients[1], "15");
//Nr 15
recipes[14].index = 15;
recipes[14].food_preference = 1;
strcpy(recipes[14].ingredients[0], "9");
//Nr 16
recipes[15].index = 16;
recipes[15].food_preference = 1;
strcpy(recipes[15].ingredients[0], "8");
strcpy(recipes[15].ingredients[1], "10");
//Nr 17
recipes[16].index = 17;
recipes[16].food_preference = 1;
strcpy(recipes[16].ingredients[0], "8");
strcpy(recipes[16].ingredients[1], "15");
//Nr 18
recipes[17].index = 18;
recipes[17].food_preference = 1;
strcpy(recipes[17].ingredients[0], "9");

////-----Vegetarian-----////
//Nr 19
recipes[18].index = 1;
recipes[18].food_preference = 2;
strcpy(recipes[18].ingredients[0], "14");

//Nr 20
recipes[19].index = 2;
recipes[19].food_preference = 2;
strcpy(recipes[19].ingredients[0], "10");
strcpy(recipes[19].ingredients[1], "6");
strcpy(recipes[19].ingredients[2], "14");
//Nr 21
recipes[20].index = 3;
recipes[20].food_preference = 2;
strcpy(recipes[20].ingredients[0], "8");

//Nr 22
recipes[21].index = 4;
recipes[21].food_preference = 2;
strcpy(recipes[21].ingredients[0], "9");
strcpy(recipes[21].ingredients[1], "11");
strcpy(recipes[21].ingredients[2], "10");

//Nr 23
recipes[22].index = 5;
recipes[22].food_preference = 2;
strcpy(recipes[22].ingredients[0], "10");
strcpy(recipes[22].ingredients[1], "8");

//Nr 24
recipes[23].index = 6;
recipes[23].food_preference = 2;
strcpy(recipes[23].ingredients[0], "14");

//Nr 25
recipes[24].index = 7;
recipes[24].food_preference = 2;
strcpy(recipes[24].ingredients[0], "10");

//Nr 26
recipes[25].index = 8;
recipes[25].food_preference = 2;
strcpy(recipes[25].ingredients[0], "10");

//Nr 27
recipes[26].index = 9;
recipes[26].food_preference = 2;
strcpy(recipes[26].ingredients[0], "9");
strcpy(recipes[26].ingredients[1], "10");

//Nr 28
recipes[27].index = 10;
recipes[27].food_preference = 2;
strcpy(recipes[27].ingredients[0], "8");
strcpy(recipes[27].ingredients[1], "10");
strcpy(recipes[27].ingredients[2], "12");
strcpy(recipes[27].ingredients[3], "13");
//Nr 29
recipes[28].index = 11;
recipes[28].food_preference = 2;
//Nr 30
recipes[29].index = 12;
recipes[29].food_preference = 2;
strcpy(recipes[29].ingredients[0], "10");
strcpy(recipes[29].ingredients[1], "11");
//Nr 31
recipes[30].index = 13;
recipes[30].food_preference = 2;
strcpy(recipes[30].ingredients[0], "10");
strcpy(recipes[30].ingredients[1], "11");
//Nr 32
recipes[31].index = 14;
recipes[31].food_preference = 2;
strcpy(recipes[31].ingredients[0], "13");
//Nr 33
recipes[32].index = 15;
recipes[32].food_preference = 2;
strcpy(recipes[32].ingredients[0], "6");
strcpy(recipes[32].ingredients[1], "11");
strcpy(recipes[32].ingredients[2], "9");
strcpy(recipes[32].ingredients[3], "13");
//Nr 34
recipes[33].index = 16;
recipes[33].food_preference = 2;
strcpy(recipes[33].ingredients[0], "11");
//Nr 35
recipes[34].index = 17;
recipes[34].food_preference = 2;
strcpy(recipes[34].ingredients[0], "14");
//Nr 36
recipes[35].index = 18;
recipes[35].food_preference = 2;
////-----Omnivore-----////
//Nr 37
recipes[36].index = 1;
recipes[36].food_preference = 3;
recipes[36].points = 0;
strcpy(recipes[36].ingredients[0], "2");
strcpy(recipes[36].ingredients[1], "6");
strcpy(recipes[36].ingredients[2], "10");
//Nr 38
recipes[37].index = 2;
recipes[37].food_preference = 3;
recipes[37].points = 0;
strcpy(recipes[37].ingredients[0], "3");
//Nr 39
recipes[38].index = 3;
recipes[38].food_preference = 3;
strcpy(recipes[38].ingredients[0], "3");
strcpy(recipes[38].ingredients[1], "6");
//Nr 40
recipes[39].index = 4;
recipes[39].food_preference = 3;
strcpy(recipes[39].ingredients[0], "4");
strcpy(recipes[39].ingredients[1], "6");
strcpy(recipes[39].ingredients[2], "10");
strcpy(recipes[39].ingredients[3], "11");
//Nr 41
recipes[40].index = 5;
recipes[40].food_preference = 3;
strcpy(recipes[40].ingredients[0], "3");
strcpy(recipes[40].ingredients[1], "6");
strcpy(recipes[40].ingredients[2], "10");
//Nr 42
recipes[41].index = 6;
recipes[41].food_preference = 3;
strcpy(recipes[41].ingredients[0], "3");
strcpy(recipes[41].ingredients[1], "6");
strcpy(recipes[41].ingredients[2], "7");
strcpy(recipes[41].ingredients[3], "10");
//Nr 43
recipes[42].index = 7;
recipes[42].food_preference = 3;
strcpy(recipes[42].ingredients[0], "3");
strcpy(recipes[42].ingredients[1], "4");
strcpy(recipes[42].ingredients[2], "6");
strcpy(recipes[42].ingredients[3], "10");
//Nr 44
recipes[43].index = 8;
recipes[43].food_preference = 3;
//Nr 45
recipes[44].index = 9;
recipes[44].food_preference = 3;
strcpy(recipes[44].ingredients[0], "3");
//Nr 46
recipes[45].index = 10;
recipes[45].food_preference = 3;
strcpy(recipes[45].ingredients[0], "3");
//Nr 47
recipes[46].index = 11;
recipes[46].food_preference = 3;
strcpy(recipes[46].ingredients[0], "4");
strcpy(recipes[46].ingredients[1], "6");
strcpy(recipes[46].ingredients[2], "7");
strcpy(recipes[46].ingredients[3], "10");
//Nr 48
recipes[47].index = 12;
recipes[47].food_preference = 3;
strcpy(recipes[47].ingredients[0], "1");
strcpy(recipes[47].ingredients[1], "8");
strcpy(recipes[47].ingredients[2], "10");
//Nr 49
recipes[48].index = 13;
recipes[48].food_preference = 3;
strcpy(recipes[48].ingredients[0], "4");
strcpy(recipes[48].ingredients[1], "9");
strcpy(recipes[48].ingredients[2], "10");
//Nr 50
recipes[49].index = 14;
recipes[49].food_preference = 3;
strcpy(recipes[49].ingredients[0], "3");
strcpy(recipes[49].ingredients[1], "11");
//Nr 51
recipes[50].index = 15;
recipes[50].food_preference = 3;
strcpy(recipes[50].ingredients[0], "3");
strcpy(recipes[50].ingredients[1], "13");
//Nr 52
recipes[51].index = 16;
recipes[51].food_preference = 3;
strcpy(recipes[51].ingredients[0], "14");
//Nr 53
recipes[52].index = 17;
recipes[52].food_preference = 3;
//Nr 54
recipes[53].index = 18;
recipes[53].food_preference = 3;
strcpy(recipes[53].ingredients[0], "11");