#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

//All of our functions
#include "functions.h"

int main(void)
{
    Startup();
    
    return 0;
}

void Startup(){
    int food_preference;
    int no_waste; 

    Introduction(&food_preference, &no_waste);

    switch (no_waste)
    {
        case 1:
            SimpleMealPlanGenerator(food_preference);
            break;

        case 2:
            FoodWasteTerminator3000(food_preference);
            break;
            
        default:
            printf("\nInvalid input");
            Startup();
            break;
    }
}

void Introduction(int *food_preference, int *no_waste){
    printf("\nMealDeal\n\n");
    printf("Welcome to MealDeal! - a great deal for a nice meal!\n\n");
    printf("MealDeal is a program designed to help students on a budget to reduce food waste while also being able to eat well.\n");
    printf("No money? No problem! Great food doesn\'t have to be expensive. We believe that great food can be made with low cost and lots of love!\n");
    printf("All you need is a nice recipe with affordable ingredients and the will to make a change.\n");
    printf("Lets get started! MealDeal offers the following two options:\n");

    printf("    - 1: Empty fridge? Let us make a delicious 7-day meal plan - just for you!\n");
    printf("    - 2: Avoid food waste! Tell us what you have in your fridge and we’ll show you what you can make from it!\n");

    printf("What option would you like to choose? Type 1 or 2 according to your choice and tap 'ENTER':  \n");
    scanf("%d", no_waste);

    //Boost your mood! Eat some food ;))

    printf("Nice choice! Do you want your meals to be vegan (1) vegetarian (2) or omnivore (3)?\n");
    printf("Type the number of your preference. Then tap 'ENTER':  ");
    scanf("%d", food_preference);
}

//--Den simple metode--//
void SimpleMealPlanGenerator(int food_preference){
    int count = 0;
    FILE *inp;
    switch (food_preference)
    {
        case 1:
            inp = fopen("vegan.txt", "r");
            break;
        case 2:
            inp = fopen("vegetarian.txt", "r");
            break;
        case 3:
            inp = fopen("omnivore.txt", "r");
            break;
        default:
            printf("Invalid input.\n");
            break;
    }

    int data_status;
    char item[1];

    //Prebens del (Ich bin eine Maschine)
    int days[7], x;

    srand(time(NULL));
    
    for(int i = 0; i < 7; i++){
        days[i] = rand() % 18 + 1;

        for(int j = 0; j < 7; j++){
            if(i == j){

            } else if(days[i] == days[j]){
                x = days[i];

                while(days[0] == x || days[1] == x ||
                      days[2] == x || days[3] == x ||
                      days[4] == x || days[5] == x ||
                      days[6] == x){
                          x = rand() % 18 + 1;
                      }
                days[i] = x;
            }
        }
    }

    data_status = fscanf(inp, "%c", &item);

    while (data_status == 1)
    {
        if (*item == '=')
        {
            count++;
            *item = ' ';
        }
        
        for (int i = 0; i < 7; i++)
        {
            if (count == days[i])
            {
                printf("%c", *item);
            }
        }
        
        data_status = fscanf(inp, "%c", &item);
    }
}

void FoodWasteTerminator3000(int food_preference){
    //All the recipe setups
    #include "recipes.h"

    int count = 0;
    FILE *inp;
    switch (food_preference)
    {
        case 1:
            inp = fopen("vegan.txt", "r");
            break;
        case 2:
            inp = fopen("vegetarian.txt", "r");
            break;
        case 3:
            inp = fopen("omnivore.txt", "r");
            break;
        default:
            printf("Invalid input.\n");
            break;
    }
    int data_status;
    char item[1];

    //Variables
    char myingredients[100][10] = {"", "", "", "", "", "", "", "", "", ""};

    //Bruger vælger ingredientsedienser
    EmptyFridge();
    int i = 0;
    char d[10];
    while(strcmp(d, "q"))
    {
        scanf("%s", d);
        strcpy(myingredients[i], d);
        i++;
    }
    
    //Find bedste opskrift
    int size = sizeof(recipes) / sizeof(recipes[0]);
    int size2 = sizeof(myingredients) / sizeof(myingredients[0]);

    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size2; j++)
        {
            for (int q = 0; q < 4; q++)
            {
                if (!strcmp(myingredients[j], recipes[i].ingredients[q]))
                {
                    recipes[i].points++;
                }
            }
        }
    }
    //Set highestIndex til vinderen
    int index = 0;
    int points = 0;
    for (int i = 0; i < 54; i++)
    {
        if (points < recipes[i].points && recipes[i].food_preference == food_preference)
        {
            points = recipes[i].points;
            index = recipes[i].index;
        }
    }

    data_status = fscanf(inp, "%c", &item);

    while (data_status == 1)
    {
        if (*item == '=')
        {
            count++;
            *item = ' ';
        }
        if (count == index)
        {
            printf("%c", *item);
        }
        
        data_status = fscanf(inp, "%c", &item);
    }
}

void EmptyFridge () {
    printf("Type the numbers corresponding to the ingredients you have (type q to quit):\n");
    printf("       Meat       |      Vegetables    |     Other  \n");  
    printf("1: Salmon         | 6:  Carrot         | 11: Egg    \n"); 
    printf("2: Ground beef    | 7:  Potato         | 12: Tofu   \n"); 
    printf("3: Chicken        | 8:  Tomato         | 13: Rice   \n"); 
    printf("4: Bacon          | 9:  Mushrooms      | 14: Pasta  \n"); 
    printf("5: Ground pork    | 10: Onions         | 15: Beans  \n"); 
}